$(document).ready(function(){
	$('.carousele').slick(
	{
		arrows: false,
		autoplay: true
	});
});